import { spawn } from "child_process"

async function inference(x){
    const pythonProcess = spawn('python',['./run_model.py', x[0], x[1], x[2], x[3], x[4], x[5], x[6], x[7]]);
    // const pythonProcess = spawn('python', ['./hello.py']);
    pythonProcess.stdout.on('data', (data) => {
        console.log(data.toString());
        return data;
    });
}

export default inference;